# GlimmerCircuitLab

my code of njucircuit lab during glimmer

- Mux21
- 8-3encoder
- ALU
- shift register
- status machine and ps2-keyboard
